using System;

namespace LibrarySystem
{
    // Nobody is ever registered as "just a person" -> protected constructor,
    // only Member and Staff (and their own children) can call it.
    public class Person
    {
        public string PersonId { get; }
        public string FullName { get; }
        public string Phone { get; }

        protected Person(string personId, string fullName, string phone)
        {
            if (string.IsNullOrEmpty(personId))
            {
                throw new ArgumentException("PersonId must not be null or empty.");
            }
            if (string.IsNullOrEmpty(fullName))
            {
                throw new ArgumentException("FullName must not be null or empty.");
            }
            if (string.IsNullOrEmpty(phone))
            {
                throw new ArgumentException("Phone must not be null or empty.");
            }

            PersonId = personId;
            FullName = fullName;
            Phone = phone;
        }
    }
}
